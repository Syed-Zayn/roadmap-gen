import { create } from "zustand";
import { persist } from "zustand/middleware";

// Define specific roles to maintain strict type safety across the frontend.
// Matches the FastAPI backend UserRole Enum exactly.
export type UserRole = "Student" | "Teacher" | string;

interface AppState {
  accessToken: string | null;
  userRole: UserRole | null;
  
  // Enterprise Fix: Track hydration state to prevent premature Next.js redirects
  _hasHydrated: boolean; 
  
  // Action to securely save the session data after a successful login
  setAuth: (token: string, role: UserRole) => void;
  
  // Action to wipe out all session data during logout or 401 Unauthorized errors
  clearAuth: () => void;

  // Internal action strictly used by persist middleware to acknowledge storage load
  setHasHydrated: (state: boolean) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      // Initial state is completely empty (unauthenticated)
      accessToken: null,
      userRole: null,
      _hasHydrated: false, // Strictly false until localStorage is fully read
      
      // Atomically updates both the token and the role in a single state change
      setAuth: (token, role) => 
        set({ 
          accessToken: token, 
          userRole: role 
        }),
        
      // Securely flushes the authentication context
      clearAuth: () => 
        set({ 
          accessToken: null, 
          userRole: null 
        }),
        
      // Updates hydration status
      setHasHydrated: (state) => set({ _hasHydrated: state }),
    }),
    {
      name: "app-auth-storage", // The exact key used in the browser's localStorage
      
      // Enterprise Integration: Hooks into the persist lifecycle.
      // Triggers when Zustand successfully syncs the state with the browser's storage.
      onRehydrateStorage: () => (state) => {
        if (state) {
          state.setHasHydrated(true);
        }
      },
    }
  )
);