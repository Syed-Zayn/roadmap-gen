"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";

export default function CustomCursor() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isHovering, setIsHovering] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Enterprise Performance Optimization: Disable custom cursor on touch devices
    // to prevent stuck cursors and save mobile battery/CPU cycles.
    if (typeof window !== "undefined" && window.matchMedia("(pointer: coarse)").matches) {
      return;
    }

    const updateMousePosition = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
      if (!isVisible) setIsVisible(true);
    };

    const handleMouseInteraction = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      
      // Dynamically detect if the user is hovering over any interactive element.
      // We check the element itself and its closest parents to cover nested SVG icons/spans inside buttons.
      const isInteractive = 
        target.tagName.toLowerCase() === "button" ||
        target.tagName.toLowerCase() === "a" ||
        target.tagName.toLowerCase() === "input" ||
        target.tagName.toLowerCase() === "select" ||
        target.closest("button") !== null ||
        target.closest("a") !== null;

      setIsHovering(isInteractive);
    };

    // Attach passive event listeners for maximum performance
    window.addEventListener("mousemove", updateMousePosition, { passive: true });
    window.addEventListener("mouseover", handleMouseInteraction, { passive: true });

    return () => {
      // Memory Leak Prevention: Clean up event listeners on component unmount
      window.removeEventListener("mousemove", updateMousePosition);
      window.removeEventListener("mouseover", handleMouseInteraction);
    };
  }, [isVisible]);

  // Do not render anything until the first mouse movement is detected
  // This prevents the cursor from awkwardly spawning in the top-left corner on load
  if (!isVisible) return null;

  return (
    <>
      {/* Outer Trailing Cursor:
        Uses a 'mix-blend-difference' effect for a high-end, premium feel.
        Expands seamlessly when hovering over clickable elements. 
      */}
      <motion.div
        className="pointer-events-none fixed top-0 left-0 z-[10000] rounded-full mix-blend-difference hidden md:block"
        animate={{
          x: mousePosition.x - (isHovering ? 24 : 12),
          y: mousePosition.y - (isHovering ? 24 : 12),
          width: isHovering ? 48 : 24,
          height: isHovering ? 48 : 24,
          backgroundColor: isHovering ? "rgba(255, 255, 255, 1)" : "rgba(255, 255, 255, 0.4)",
        }}
        transition={{ 
          type: "tween", 
          ease: "backOut", 
          duration: 0.15 
        }}
      />
      
      {/* Inner Core Dot:
        A sharp, glowing primary-colored dot that follows the exact mouse coordinates instantly.
      */}
      <motion.div
        className="pointer-events-none fixed top-0 left-0 z-[10000] h-2 w-2 rounded-full bg-primary shadow-[0_0_12px_rgba(100,50,255,0.9)] hidden md:block"
        animate={{
          x: mousePosition.x - 4,
          y: mousePosition.y - 4,
          scale: isHovering ? 0.5 : 1, // Shrink the core dot slightly when hovering
        }}
        transition={{ 
          type: "tween", 
          ease: "linear", 
          duration: 0 
        }}
      />
    </>
  );
}