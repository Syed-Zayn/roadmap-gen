"use client";

import { AnimatePresence, motion } from "framer-motion";
import { usePathname } from "next/navigation";

// Importing the modularized enterprise UI components
import CustomCursor from "./CustomCursor";
import ScrollProgressBar from "./ScrollProgressBar";
import AIChatAgent from "./AIChatAgent";

/**
 * GlobalUIProvider acts as the central client-side wrapper for the application.
 * It injects global animations, trackers, and widgets without polluting the Server-Side layout.
 */
export default function GlobalUIProvider({ children }: { children: React.ReactNode }) {
  // Pathname is used to uniquely identify route changes for Framer Motion's AnimatePresence
  const pathname = usePathname();

  return (
    <>
      {/* 1. Global Scroll Progress Indicator (Masla 5) */}
      <ScrollProgressBar />

      {/* 2. Premium Interactive Custom Cursor (Masla 5) */}
      <CustomCursor />

      {/* 3. Global AI Chat Agent (Masla 4) 
          This will persist across all pages, retaining chat history during navigation. 
          It internally handles auth-checks so it only shows for logged-in users.
      */}
      <AIChatAgent />

      {/* 4. Global Page Transitions (Masla 5) 
          Adds a premium blur and slide effect whenever the Next.js router changes pages.
      */}
      <AnimatePresence mode="wait">
        <motion.div
          key={pathname}
          initial={{ opacity: 0, y: 15, filter: "blur(5px)" }}
          animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
          exit={{ opacity: 0, y: -15, filter: "blur(5px)" }}
          transition={{ duration: 0.4, ease: "easeInOut" }}
          className="flex-1 flex flex-col w-full h-full min-h-screen"
        >
          {children}
        </motion.div>
      </AnimatePresence>
    </>
  );
}